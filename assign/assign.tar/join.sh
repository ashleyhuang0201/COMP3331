#!/bin/bash

xterm -hold -title "Peer 15" -e "python3 p2p.py join 15 4 30" &
