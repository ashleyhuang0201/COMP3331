!! Python3 !!

To run this code:

    Initialising peers:
    python3 p2p.py init <PEER_ID> <FIRST_SUCCESSOR_ID> <SECOND_SUCCESSOR_ID> <PING_INTERVAL>


    Alternatively to initialise peers:
    sh Init.sh

    Joining peer:
    python3 p2p.py join <PEER_ID> <KNOWN_PEER_ID> <PING_INTERVAL>


    Peer departure graceful:
    type "quit" and press enter in the appropriate terminal




